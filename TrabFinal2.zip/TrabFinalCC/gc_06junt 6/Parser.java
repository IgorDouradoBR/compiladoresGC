//### This file created by BYACC 1.8(/Java extension  1.15)
//### Java capabilities added 7 Jan 97, Bob Jamison
//### Updated : 27 Nov 97  -- Bob Jamison, Joe Nieten
//###           01 Jan 98  -- Bob Jamison -- fixed generic semantic constructor
//###           01 Jun 99  -- Bob Jamison -- added Runnable support
//###           06 Aug 00  -- Bob Jamison -- made state variables class-global
//###           03 Jan 01  -- Bob Jamison -- improved flags, tracing
//###           16 May 01  -- Bob Jamison -- added custom stack sizing
//###           04 Mar 02  -- Yuval Oren  -- improved java performance, added options
//###           14 Mar 02  -- Tomas Hurka -- -d support, static initializer workaround
//### Please send bug reports to tom@hukatronic.cz
//### static char yysccsid[] = "@(#)yaccpar	1.8 (Berkeley) 01/20/90";






//#line 3 "exemploGC.y"
  import java.io.*;
  import java.util.ArrayList;
  import java.util.Stack;
//#line 21 "Parser.java"




public class Parser
{

boolean yydebug;        //do I want debug output?
int yynerrs;            //number of errors so far
int yyerrflag;          //was there an error?
int yychar;             //the current working character

//########## MESSAGES ##########
//###############################################################
// method: debug
//###############################################################
void debug(String msg)
{
  if (yydebug)
    System.out.println(msg);
}

//########## STATE STACK ##########
final static int YYSTACKSIZE = 500;  //maximum stack size
int statestk[] = new int[YYSTACKSIZE]; //state stack
int stateptr;
int stateptrmax;                     //highest index of stackptr
int statemax;                        //state when highest index reached
//###############################################################
// methods: state stack push,pop,drop,peek
//###############################################################
final void state_push(int state)
{
  try {
		stateptr++;
		statestk[stateptr]=state;
	 }
	 catch (ArrayIndexOutOfBoundsException e) {
     int oldsize = statestk.length;
     int newsize = oldsize * 2;
     int[] newstack = new int[newsize];
     System.arraycopy(statestk,0,newstack,0,oldsize);
     statestk = newstack;
     statestk[stateptr]=state;
  }
}
final int state_pop()
{
  return statestk[stateptr--];
}
final void state_drop(int cnt)
{
  stateptr -= cnt; 
}
final int state_peek(int relative)
{
  return statestk[stateptr-relative];
}
//###############################################################
// method: init_stacks : allocate and prepare stacks
//###############################################################
final boolean init_stacks()
{
  stateptr = -1;
  val_init();
  return true;
}
//###############################################################
// method: dump_stacks : show n levels of the stacks
//###############################################################
void dump_stacks(int count)
{
int i;
  System.out.println("=index==state====value=     s:"+stateptr+"  v:"+valptr);
  for (i=0;i<count;i++)
    System.out.println(" "+i+"    "+statestk[i]+"      "+valstk[i]);
  System.out.println("======================");
}


//########## SEMANTIC VALUES ##########
//public class ParserVal is defined in ParserVal.java


String   yytext;//user variable to return contextual strings
ParserVal yyval; //used to return semantic vals from action routines
ParserVal yylval;//the 'lval' (result) I got from yylex()
ParserVal valstk[];
int valptr;
//###############################################################
// methods: value stack push,pop,drop,peek.
//###############################################################
void val_init()
{
  valstk=new ParserVal[YYSTACKSIZE];
  yyval=new ParserVal();
  yylval=new ParserVal();
  valptr=-1;
}
void val_push(ParserVal val)
{
  if (valptr>=YYSTACKSIZE)
    return;
  valstk[++valptr]=val;
}
ParserVal val_pop()
{
  if (valptr<0)
    return new ParserVal();
  return valstk[valptr--];
}
void val_drop(int cnt)
{
int ptr;
  ptr=valptr-cnt;
  if (ptr<0)
    return;
  valptr = ptr;
}
ParserVal val_peek(int relative)
{
int ptr;
  ptr=valptr-relative;
  if (ptr<0)
    return new ParserVal();
  return valstk[ptr];
}
final ParserVal dup_yyval(ParserVal val)
{
  ParserVal dup = new ParserVal();
  dup.ival = val.ival;
  dup.dval = val.dval;
  dup.sval = val.sval;
  dup.obj = val.obj;
  return dup;
}
//#### end semantic value section ####
public final static short ID=257;
public final static short INT=258;
public final static short FLOAT=259;
public final static short BOOL=260;
public final static short NUM=261;
public final static short LIT=262;
public final static short VOID=263;
public final static short MAIN=264;
public final static short READ=265;
public final static short WRITE=266;
public final static short IF=267;
public final static short ELSE=268;
public final static short WHILE=269;
public final static short TRUE=270;
public final static short FALSE=271;
public final static short BREAK=272;
public final static short CONTINUE=273;
public final static short EQ=274;
public final static short LEQ=275;
public final static short GEQ=276;
public final static short NEQ=277;
public final static short AND=278;
public final static short OR=279;
public final static short INCR=280;
public final static short DO=281;
public final static short FOR=282;
public final static short YYERRCODE=256;
final static short yylhs[] = {                           -1,
    4,    0,    6,    8,    5,    3,    3,    9,    9,    1,
    1,    1,    7,    7,   10,   10,   10,   12,   10,   10,
   13,   14,   10,   15,   10,   17,   18,   19,   20,   10,
   21,   10,   10,   10,   16,   16,   23,   22,   22,   11,
   11,   11,   11,   11,   11,   11,   11,   11,   11,   11,
   11,   11,   11,   11,   11,   11,   11,   11,   11,   11,
   11,   11,   11,    2,    2,
};
final static short yylen[] = {                            2,
    0,    3,    0,    0,    9,    2,    0,    3,    6,    1,
    1,    1,    2,    0,    2,    3,    5,    0,    8,    5,
    0,    0,    7,    0,    8,    0,    0,    0,    0,   13,
    0,    7,    2,    2,    1,    0,    0,    3,    0,    1,
    1,    1,    1,    2,    2,    3,    2,    3,    3,    3,
    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,
    3,    4,    3,    1,    4,
};
final static short yydefred[] = {                         1,
    0,    0,   10,   11,   12,    0,    0,    0,    0,    0,
    2,    6,    8,    0,    0,    0,    0,    0,    3,    9,
    0,   14,    0,    0,   40,    0,    0,    0,   21,   41,
   42,    0,    0,    0,   24,    0,    0,   14,    0,    0,
    0,   13,    0,   44,    0,    0,    0,    0,    0,    0,
   33,   34,   45,    0,   47,    0,    0,   26,    0,    5,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,   15,    0,    0,    0,    0,    0,    0,
    0,    0,   46,   16,    0,   63,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,   50,   51,   52,   62,
   65,    0,    0,    0,    0,    0,    0,    0,    0,   20,
   17,    0,    0,   22,    0,   27,    0,    0,    0,    0,
    0,    0,   37,   32,   23,    0,    0,   19,    0,   25,
   28,   38,    0,   29,    0,    0,   30,
};
final static short yydgoto[] = {                          1,
    6,   40,    7,    2,   11,   21,   23,   41,    8,   42,
   43,  104,   50,  119,   54,  109,   85,  121,  133,  135,
  105,  124,  129,
};
final static short yysindex[] = {                         0,
    0, -232,    0,    0,    0, -249, -253, -232,  -56, -251,
    0,    0,    0, -246,  -23,  -63,   -9,  -26,    0,    0,
  -89,    0,    3,  -60,    0,   -3,   -2,   -1,    0,    0,
    0,  -19,  -17, -216,    0,   20,   20,    0,    4,  -16,
  -79,    0,   41,    0,   20,   25, -210, -214,   20,   11,
    0,    0,    0,    3,    0,   70,  -33,    0, -212,    0,
   20,   20,   20,   20,   20,   20,   20,   20,   20,   20,
   20,   20,   20,    0,  120,  -41,   77,   14,   15,  120,
   20, -208,    0,    0,   20,    0,  -31,  -31,  -31,  -31,
   27,  141,  -31,  -31,  -18,  -18,    0,    0,    0,    0,
    0,    7,    8,   18,   22,   99,   19,  120,   21,    0,
    0,   20,    3,    0,   20,    0,  106, -195,    3,  113,
   20,   23,    0,    0,    0,   26,   32,    0,    3,    0,
    0,    0,   20,    0,   54,    3,    0,
};
final static short yyrindex[] = {                         0,
    0, -166,    0,    0,    0,    0,    0, -166,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,  -27,   34,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,  -39,  134,    0,    0,   55,   63,
    0,    0,    0,    0,   46,    0,  265,  273,  300,  309,
    9,  -36,  345,  380,  148,  387,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,  -37,    0,    0,
    0,    0,    0,    0,    0,    0,    0,  -15,    0,    0,
   46,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,   65,    0,    0,    0,    0,
};
final static short yygindex[] = {                         0,
    0,    0,  101,    0,    0,    0,   78,    0,    0,  316,
  447,    0,    0,    0,    0, -112,    0,    0,    0,    0,
    0,    0,    0,
};
final static int YYTABLESIZE=666;
static short yytable[];
static { yytable();}
static void yytable(){
yytable = new short[]{                         36,
   45,   61,   13,   35,   59,   73,   37,    9,  127,   10,
   71,   69,   15,   70,   16,   72,   17,   39,   73,   61,
  134,   35,   59,   71,   39,    3,    4,    5,   72,   18,
   46,   19,   20,   22,   14,   36,   47,   48,   49,   51,
   53,   52,   37,   58,   59,   60,   78,   79,   86,   60,
   81,  100,   36,   61,  102,  103,   59,   36,  115,   37,
  107,  112,  113,   73,   37,  110,  111,   60,   71,   69,
   43,   70,  123,   72,   43,   43,   43,   73,   43,  116,
   43,  128,   71,   69,  130,   70,   68,   72,   67,   38,
  131,   84,   43,   43,  136,   43,    7,    4,   18,   74,
   68,   60,   67,   31,   36,   36,   73,   39,   12,   39,
   83,   71,   69,   73,   70,   57,   72,    0,   71,   69,
    0,   70,    0,   72,    0,   38,   43,    0,    0,   68,
    0,   67,    0,    0,    0,   73,   68,    0,   67,  114,
   71,   69,   73,   70,    0,   72,  122,   71,   69,   73,
   70,    0,   72,  126,   71,   69,   73,   70,   68,   72,
   67,   71,   69,    0,   70,   68,   72,   67,    0,  101,
   40,    0,   68,    0,   67,   40,   40,   73,   40,   68,
   40,   67,   71,   69,    0,   70,    0,   72,   48,    0,
   48,    0,   48,   40,    0,   40,    0,    0,    0,    0,
   68,    0,   67,    0,    0,    0,   48,   48,    0,   48,
    0,    0,    0,    0,    0,    0,    0,    0,    0,   44,
    0,    0,    0,   24,    0,    0,    0,   25,    0,    0,
    0,   26,   27,   28,    0,   29,   30,   31,   32,   33,
   48,   39,   59,    0,    0,   39,   34,   35,   39,   39,
   39,   39,    0,   39,   39,   39,   39,   39,    0,   24,
    0,    0,    0,   25,   39,   39,   39,   26,   27,   28,
    0,   29,   30,   31,   32,   33,   24,    0,    0,    0,
   25,   24,   34,   35,   39,   76,   60,   60,    0,   30,
   31,    0,    0,    0,   30,   31,    0,    0,    0,   34,
   61,   62,   63,   64,   34,   55,    0,   43,   43,   43,
   43,   43,   43,   56,   61,   62,   63,   64,   65,   66,
    0,    0,    0,   55,   55,    0,   55,    0,    0,    0,
    0,   56,   56,    0,   56,    0,    0,    0,    0,    0,
   57,    0,    0,   61,   62,   63,   64,   65,   66,   58,
   61,   62,   63,   64,   65,   66,    0,   55,   57,   57,
    0,   57,    0,    0,    0,   56,    0,   58,   58,   82,
   58,    0,   61,   62,   63,   64,   65,   66,    0,   61,
   62,   63,   64,   65,   66,   53,   61,   62,   63,   64,
   65,   66,   57,   61,   62,   63,   64,   65,   66,    0,
    0,   58,    0,   53,   53,    0,   53,   40,   40,   40,
   40,   40,   40,    0,   61,   62,   63,   64,   65,    0,
   54,   48,   48,   48,   48,   48,   48,   49,  118,   49,
    0,   49,    0,    0,  125,    0,    0,   53,   54,   54,
    0,   54,    0,    0,  132,   49,   49,    0,   49,    0,
    0,  137,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,   54,    0,    0,    0,    0,    0,    0,   49,
    0,    0,   55,   56,    0,    0,    0,    0,    0,    0,
    0,   75,   77,    0,    0,   80,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,   87,   88,   89,
   90,   91,   92,   93,   94,   95,   96,   97,   98,   99,
    0,    0,    0,    0,    0,    0,    0,  106,    0,    0,
    0,  108,    0,    0,    0,    0,    0,    0,   55,   55,
   55,   55,   55,   55,    0,    0,   56,   56,   56,   56,
   56,   56,    0,    0,    0,    0,    0,    0,  117,    0,
    0,  120,    0,    0,    0,    0,    0,  108,    0,    0,
    0,    0,    0,   57,   57,   57,   57,   57,   57,  108,
    0,    0,   58,   58,   58,   58,   58,   58,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,   53,   53,
   53,   53,   53,   53,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,   54,   54,   54,   54,   54,   54,    0,
   49,   49,   49,   49,   49,   49,
};
}
static short yycheck[];
static { yycheck(); }
static void yycheck() {
yycheck = new short[] {                         33,
   61,   41,   59,   41,   41,   37,   40,  257,  121,  263,
   42,   43,  264,   45,  261,   47,   40,   33,   37,   59,
  133,   59,   59,   42,   40,  258,  259,  260,   47,   93,
   91,   41,   59,  123,   91,   33,   40,   40,   40,   59,
  257,   59,   40,   40,   61,  125,  257,  262,  261,   41,
   40,   93,   33,   93,   41,   41,   93,   33,   40,   40,
  269,   44,   41,   37,   40,   59,   59,   59,   42,   43,
   37,   45,  268,   47,   41,   42,   43,   37,   45,   59,
   47,   59,   42,   43,   59,   45,   60,   47,   62,  123,
   59,  125,   59,   60,   41,   62,  263,  125,   44,   59,
   60,   93,   62,   41,   59,   41,   37,  123,    8,  125,
   41,   42,   43,   37,   45,   38,   47,   -1,   42,   43,
   -1,   45,   -1,   47,   -1,  123,   93,   -1,   -1,   60,
   -1,   62,   -1,   -1,   -1,   37,   60,   -1,   62,   41,
   42,   43,   37,   45,   -1,   47,   41,   42,   43,   37,
   45,   -1,   47,   41,   42,   43,   37,   45,   60,   47,
   62,   42,   43,   -1,   45,   60,   47,   62,   -1,   93,
   37,   -1,   60,   -1,   62,   42,   43,   37,   45,   60,
   47,   62,   42,   43,   -1,   45,   -1,   47,   41,   -1,
   43,   -1,   45,   60,   -1,   62,   -1,   -1,   -1,   -1,
   60,   -1,   62,   -1,   -1,   -1,   59,   60,   -1,   62,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,  280,
   -1,   -1,   -1,  257,   -1,   -1,   -1,  261,   -1,   -1,
   -1,  265,  266,  267,   -1,  269,  270,  271,  272,  273,
   93,  257,  279,   -1,   -1,  261,  280,  281,  282,  265,
  266,  267,   -1,  269,  270,  271,  272,  273,   -1,  257,
   -1,   -1,   -1,  261,  280,  281,  282,  265,  266,  267,
   -1,  269,  270,  271,  272,  273,  257,   -1,   -1,   -1,
  261,  257,  280,  281,  282,  261,  278,  279,   -1,  270,
  271,   -1,   -1,   -1,  270,  271,   -1,   -1,   -1,  280,
  274,  275,  276,  277,  280,   41,   -1,  274,  275,  276,
  277,  278,  279,   41,  274,  275,  276,  277,  278,  279,
   -1,   -1,   -1,   59,   60,   -1,   62,   -1,   -1,   -1,
   -1,   59,   60,   -1,   62,   -1,   -1,   -1,   -1,   -1,
   41,   -1,   -1,  274,  275,  276,  277,  278,  279,   41,
  274,  275,  276,  277,  278,  279,   -1,   93,   59,   60,
   -1,   62,   -1,   -1,   -1,   93,   -1,   59,   60,   54,
   62,   -1,  274,  275,  276,  277,  278,  279,   -1,  274,
  275,  276,  277,  278,  279,   41,  274,  275,  276,  277,
  278,  279,   93,  274,  275,  276,  277,  278,  279,   -1,
   -1,   93,   -1,   59,   60,   -1,   62,  274,  275,  276,
  277,  278,  279,   -1,  274,  275,  276,  277,  278,   -1,
   41,  274,  275,  276,  277,  278,  279,   41,  113,   43,
   -1,   45,   -1,   -1,  119,   -1,   -1,   93,   59,   60,
   -1,   62,   -1,   -1,  129,   59,   60,   -1,   62,   -1,
   -1,  136,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   93,   -1,   -1,   -1,   -1,   -1,   -1,   93,
   -1,   -1,   36,   37,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   45,   46,   -1,   -1,   49,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   61,   62,   63,
   64,   65,   66,   67,   68,   69,   70,   71,   72,   73,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   81,   -1,   -1,
   -1,   85,   -1,   -1,   -1,   -1,   -1,   -1,  274,  275,
  276,  277,  278,  279,   -1,   -1,  274,  275,  276,  277,
  278,  279,   -1,   -1,   -1,   -1,   -1,   -1,  112,   -1,
   -1,  115,   -1,   -1,   -1,   -1,   -1,  121,   -1,   -1,
   -1,   -1,   -1,  274,  275,  276,  277,  278,  279,  133,
   -1,   -1,  274,  275,  276,  277,  278,  279,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,  274,  275,
  276,  277,  278,  279,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,  274,  275,  276,  277,  278,  279,   -1,
  274,  275,  276,  277,  278,  279,
};
}
final static short YYFINAL=1;
final static short YYMAXTOKEN=282;
final static String yyname[] = {
"end-of-file",null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,"'!'",null,null,null,"'%'",null,null,"'('","')'","'*'","'+'",
"','","'-'",null,"'/'",null,null,null,null,null,null,null,null,null,null,null,
"';'","'<'","'='","'>'",null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,"'['",null,"']'",null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,"'{'",null,"'}'",null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
null,null,null,null,null,null,null,null,null,"ID","INT","FLOAT","BOOL","NUM",
"LIT","VOID","MAIN","READ","WRITE","IF","ELSE","WHILE","TRUE","FALSE","BREAK",
"CONTINUE","EQ","LEQ","GEQ","NEQ","AND","OR","INCR","DO","FOR",
};
final static String yyrule[] = {
"$accept : prog",
"$$1 :",
"prog : $$1 dList mainF",
"$$2 :",
"$$3 :",
"mainF : VOID MAIN '(' ')' $$2 '{' lcmd $$3 '}'",
"dList : decl dList",
"dList :",
"decl : type ID ';'",
"decl : type ID '[' NUM ']' ';'",
"type : INT",
"type : FLOAT",
"type : BOOL",
"lcmd : lcmd cmd",
"lcmd :",
"cmd : exp ';'",
"cmd : '{' lcmd '}'",
"cmd : WRITE '(' LIT ')' ';'",
"$$4 :",
"cmd : WRITE '(' LIT $$4 ',' exp ')' ';'",
"cmd : READ '(' ID ')' ';'",
"$$5 :",
"$$6 :",
"cmd : WHILE $$5 '(' exp ')' $$6 cmd",
"$$7 :",
"cmd : DO $$7 cmd WHILE '(' exp ')' ';'",
"$$8 :",
"$$9 :",
"$$10 :",
"$$11 :",
"cmd : FOR '(' $$8 ExpOpc ';' $$9 ExpOpc ';' $$10 ExpOpc $$11 ')' cmd",
"$$12 :",
"cmd : IF '(' exp $$12 ')' cmd restoIf",
"cmd : BREAK ';'",
"cmd : CONTINUE ';'",
"ExpOpc : exp",
"ExpOpc :",
"$$13 :",
"restoIf : ELSE $$13 cmd",
"restoIf :",
"exp : NUM",
"exp : TRUE",
"exp : FALSE",
"exp : ID",
"exp : ID INCR",
"exp : INCR ID",
"exp : '(' exp ')'",
"exp : '!' exp",
"exp : exp '+' exp",
"exp : exp '-' exp",
"exp : exp '*' exp",
"exp : exp '/' exp",
"exp : exp '%' exp",
"exp : exp '>' exp",
"exp : exp '<' exp",
"exp : exp EQ exp",
"exp : exp LEQ exp",
"exp : exp GEQ exp",
"exp : exp NEQ exp",
"exp : exp OR exp",
"exp : exp AND exp",
"exp : ID '=' exp",
"exp : ID '[' NUM ']'",
"exp : ref '=' NUM",
"ref : ID",
"ref : ID '[' exp ']'",
};

//#line 264 "exemploGC.y"

  private Yylex lexer;

  private TabSimb ts = new TabSimb();

  private int strCount = 0;
  private ArrayList<String> strTab = new ArrayList<String>();

  
  private Stack<Integer>   pRot = new Stack<Integer>();
  private Stack<Integer> pBreakContinue = new Stack<Integer>();
  private int proxBreakContinue = 1;
  private int proxRot = 1;

  public static int ARRAY = 100;

  private int yylex () {
    int yyl_return = -1;
		try {
			yylval = new ParserVal(0);
			yyl_return = lexer.yylex();
		}
    	catch (IOException e) {
    		System.err.println("IO error :"+e);
    	}
    	return yyl_return;
  	}


  	public void yyerror (String error) {
		System.err.println ("Error: " + error + "  linha: " + lexer.getLine());
  	}


  public Parser(Reader r) {
    lexer = new Yylex(r, this);
  }  

  public void setDebug(boolean debug) {
    yydebug = debug;
  }

  public void listarTS() { ts.listar();}

  public static void main(String args[]) throws IOException {
		Parser yyparser;
		if ( args.length > 0 ) {
			// parse a file
			yyparser = new Parser(new FileReader(args[0]));
			yyparser.yyparse();
			// yyparser.listarTS();
		}
		else {
			// interactive mode
			System.out.println("\n\tFormato: java Parser entrada.cmm >entrada.s\n");
		}
	}

   private void geraInicio() {
			System.out.println(".text\n\n#\t nome COMPLETO e matricula dos componentes do grupo...\n#\n");
			System.out.println(".GLOBL _start\n\n");  
   }

   private void geraFinal(){
			System.out.println("\n\n");
			System.out.println("#");
			System.out.println("# devolve o controle para o SO (final da main)");
			System.out.println("#");
			System.out.println("\tmov $0, %ebx");
			System.out.println("\tmov $1, %eax");
			System.out.println("\tint $0x80");
	
			System.out.println("\n");
			System.out.println("#");
			System.out.println("# Funcoes da biblioteca (IO)");
			System.out.println("#");
			System.out.println("\n");
			System.out.println("_writeln:");
			System.out.println("\tMOVL $__fim_msg, %ECX");
			System.out.println("\tDECL %ECX");
			System.out.println("\tMOVB $10, (%ECX)");
			System.out.println("\tMOVL $1, %EDX");
			System.out.println("\tJMP _writeLit");
			System.out.println("_write:");
			System.out.println("\tMOVL $__fim_msg, %ECX");
			System.out.println("\tMOVL $0, %EBX");
			System.out.println("\tCMPL $0, %EAX");
			System.out.println("\tJGE _write3");
			System.out.println("\tNEGL %EAX");
			System.out.println("\tMOVL $1, %EBX");
			System.out.println("_write3:");
			System.out.println("\tPUSHL %EBX");
			System.out.println("\tMOVL $10, %EBX");
			System.out.println("_divide:");
			System.out.println("\tMOVL $0, %EDX");
			System.out.println("\tIDIVL %EBX");
			System.out.println("\tDECL %ECX");
			System.out.println("\tADD $48, %DL");
			System.out.println("\tMOVB %DL, (%ECX)");
			System.out.println("\tCMPL $0, %EAX");
			System.out.println("\tJNE _divide");
			System.out.println("\tPOPL %EBX");
			System.out.println("\tCMPL $0, %EBX");
			System.out.println("\tJE _print");
			System.out.println("\tDECL %ECX");
			System.out.println("\tMOVB $'-', (%ECX)");
			System.out.println("_print:");
			System.out.println("\tMOVL $__fim_msg, %EDX");
			System.out.println("\tSUBL %ECX, %EDX");
			System.out.println("_writeLit:");
			System.out.println("\tMOVL $1, %EBX");
			System.out.println("\tMOVL $4, %EAX");
			System.out.println("\tint $0x80");
			System.out.println("\tRET");
			System.out.println("_read:");
			System.out.println("\tMOVL $15, %EDX");
			System.out.println("\tMOVL $__msg, %ECX");
			System.out.println("\tMOVL $0, %EBX");
			System.out.println("\tMOVL $3, %EAX");
			System.out.println("\tint $0x80");
			System.out.println("\tMOVL $0, %EAX");
			System.out.println("\tMOVL $0, %EBX");
			System.out.println("\tMOVL $0, %EDX");
			System.out.println("\tMOVL $__msg, %ECX");
			System.out.println("\tCMPB $'-', (%ECX)");
			System.out.println("\tJNE _reading");
			System.out.println("\tINCL %ECX");
			System.out.println("\tINC %BL");
			System.out.println("_reading:");
			System.out.println("\tMOVB (%ECX), %DL");
			System.out.println("\tCMP $10, %DL");
			System.out.println("\tJE _fimread");
			System.out.println("\tSUB $48, %DL");
			System.out.println("\tIMULL $10, %EAX");
			System.out.println("\tADDL %EDX, %EAX");
			System.out.println("\tINCL %ECX");
			System.out.println("\tJMP _reading");
			System.out.println("_fimread:");
			System.out.println("\tCMPB $1, %BL");
			System.out.println("\tJNE _fimread2");
			System.out.println("\tNEGL %EAX");
			System.out.println("_fimread2:");
			System.out.println("\tRET");
			System.out.println("\n");
     }

     private void geraAreaDados(){
			System.out.println("");		
			System.out.println("#");
			System.out.println("# area de dados");
			System.out.println("#");
			System.out.println(".data");
			System.out.println("#");
			System.out.println("# variaveis globais");
			System.out.println("#");
			ts.geraGlobais();	
			System.out.println("");
	
    }

     private void geraAreaLiterais() { 

         System.out.println("#\n# area de literais\n#");
         System.out.println("__msg:");
	       System.out.println("\t.zero 30");
	       System.out.println("__fim_msg:");
	       System.out.println("\t.byte 0");
	       System.out.println("\n");

         for (int i = 0; i<strTab.size(); i++ ) {
             System.out.println("_str_"+i+":");
             System.out.println("\t .ascii \""+strTab.get(i)+"\""); 
	           System.out.println("_str_"+i+"Len = . - _str_"+i);  
	      }		

}
   
//#line 610 "Parser.java"
//###############################################################
// method: yylexdebug : check lexer state
//###############################################################
void yylexdebug(int state,int ch)
{
String s=null;
  if (ch < 0) ch=0;
  if (ch <= YYMAXTOKEN) //check index bounds
     s = yyname[ch];    //now get it
  if (s==null)
    s = "illegal-symbol";
  debug("state "+state+", reading "+ch+" ("+s+")");
}





//The following are now global, to aid in error reporting
int yyn;       //next next thing to do
int yym;       //
int yystate;   //current parsing state from state table
String yys;    //current token string


//###############################################################
// method: yyparse : parse input and execute indicated items
//###############################################################
int yyparse()
{
boolean doaction;
  init_stacks();
  yynerrs = 0;
  yyerrflag = 0;
  yychar = -1;          //impossible char forces a read
  yystate=0;            //initial state
  state_push(yystate);  //save it
  val_push(yylval);     //save empty value
  while (true) //until parsing is done, either correctly, or w/error
    {
    doaction=true;
    if (yydebug) debug("loop"); 
    //#### NEXT ACTION (from reduction table)
    for (yyn=yydefred[yystate];yyn==0;yyn=yydefred[yystate])
      {
      if (yydebug) debug("yyn:"+yyn+"  state:"+yystate+"  yychar:"+yychar);
      if (yychar < 0)      //we want a char?
        {
        yychar = yylex();  //get next token
        if (yydebug) debug(" next yychar:"+yychar);
        //#### ERROR CHECK ####
        if (yychar < 0)    //it it didn't work/error
          {
          yychar = 0;      //change it to default string (no -1!)
          if (yydebug)
            yylexdebug(yystate,yychar);
          }
        }//yychar<0
      yyn = yysindex[yystate];  //get amount to shift by (shift index)
      if ((yyn != 0) && (yyn += yychar) >= 0 &&
          yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
        {
        if (yydebug)
          debug("state "+yystate+", shifting to state "+yytable[yyn]);
        //#### NEXT STATE ####
        yystate = yytable[yyn];//we are in a new state
        state_push(yystate);   //save it
        val_push(yylval);      //push our lval as the input for next rule
        yychar = -1;           //since we have 'eaten' a token, say we need another
        if (yyerrflag > 0)     //have we recovered an error?
           --yyerrflag;        //give ourselves credit
        doaction=false;        //but don't process yet
        break;   //quit the yyn=0 loop
        }

    yyn = yyrindex[yystate];  //reduce
    if ((yyn !=0 ) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
      {   //we reduced!
      if (yydebug) debug("reduce");
      yyn = yytable[yyn];
      doaction=true; //get ready to execute
      break;         //drop down to actions
      }
    else //ERROR RECOVERY
      {
      if (yyerrflag==0)
        {
        yyerror("syntax error");
        yynerrs++;
        }
      if (yyerrflag < 3) //low error count?
        {
        yyerrflag = 3;
        while (true)   //do until break
          {
          if (stateptr<0)   //check for under & overflow here
            {
            yyerror("stack underflow. aborting...");  //note lower case 's'
            return 1;
            }
          yyn = yysindex[state_peek(0)];
          if ((yyn != 0) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
            if (yydebug)
              debug("state "+state_peek(0)+", error recovery shifting to state "+yytable[yyn]+" ");
            yystate = yytable[yyn];
            state_push(yystate);
            val_push(yylval);
            doaction=false;
            break;
            }
          else
            {
            if (yydebug)
              debug("error recovery discarding state "+state_peek(0)+" ");
            if (stateptr<0)   //check for under & overflow here
              {
              yyerror("Stack underflow. aborting...");  //capital 'S'
              return 1;
              }
            state_pop();
            val_pop();
            }
          }
        }
      else            //discard this token
        {
        if (yychar == 0)
          return 1; //yyabort
        if (yydebug)
          {
          yys = null;
          if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
          if (yys == null) yys = "illegal-symbol";
          debug("state "+yystate+", error recovery discards token "+yychar+" ("+yys+")");
          }
        yychar = -1;  //read another
        }
      }//end error recovery
    }//yyn=0 loop
    if (!doaction)   //any reason not to proceed?
      continue;      //skip action
    yym = yylen[yyn];          //get count of terminals on rhs
    if (yydebug)
      debug("state "+yystate+", reducing "+yym+" by rule "+yyn+" ("+yyrule[yyn]+")");
    if (yym>0)                 //if count of rhs not 'nil'
      yyval = val_peek(yym-1); //get current semantic value
    yyval = dup_yyval(yyval); //duplicate yyval if ParserVal is used as semantic value
    switch(yyn)
      {
//########## USER-SUPPLIED ACTIONS ##########
case 1:
//#line 31 "exemploGC.y"
{ geraInicio(); }
break;
case 2:
//#line 31 "exemploGC.y"
{ geraAreaDados(); geraAreaLiterais(); }
break;
case 3:
//#line 33 "exemploGC.y"
{ System.out.println("_start:"); }
break;
case 4:
//#line 34 "exemploGC.y"
{ geraFinal(); }
break;
case 8:
//#line 39 "exemploGC.y"
{  TS_entry nodo = ts.pesquisa(val_peek(1).sval);
    	                if (nodo != null) 
                            yyerror("(sem) variavel >" + val_peek(1).sval + "< jah declarada");
                        else ts.insert(new TS_entry(val_peek(1).sval, val_peek(2).ival)); 
				    }
break;
case 9:
//#line 44 "exemploGC.y"
{
						TS_entry nodo = ts.pesquisa(val_peek(4).sval);
    	                if (nodo != null) 
                            yyerror("(sem) variavel >" + val_peek(4).sval + "< jah declarada");
                        else 
							ts.insert(new TS_entry(val_peek(4).sval, TabSimb.ARRAY, val_peek(2).ival, val_peek(5).ival));
	  				}
break;
case 10:
//#line 53 "exemploGC.y"
{ yyval.ival = INT; }
break;
case 11:
//#line 54 "exemploGC.y"
{ yyval.ival = FLOAT; }
break;
case 12:
//#line 55 "exemploGC.y"
{ yyval.ival = BOOL; }
break;
case 15:
//#line 62 "exemploGC.y"
{  System.out.println("\tPOPL %EDX"); 
					     }
break;
case 16:
//#line 65 "exemploGC.y"
{ System.out.println("\t\t# terminou o bloco..."); }
break;
case 17:
//#line 68 "exemploGC.y"
{ strTab.add(val_peek(2).sval);
                                System.out.println("\tMOVL $str"+strCount+"Len, %EDX"); 
				System.out.println("\tMOVL $str"+strCount+", %ECX"); 
                                System.out.println("\tCALL _writeLit"); 
				System.out.println("\tCALL _writeln"); 
                                strCount++;
				}
break;
case 18:
//#line 77 "exemploGC.y"
{ strTab.add(val_peek(0).sval);
                                System.out.println("\tMOVL $str"+strCount+"Len, %EDX"); 
				System.out.println("\tMOVL $str"+strCount+", %ECX"); 
                                System.out.println("\tCALL _writeLit"); 
				strCount++;
				}
break;
case 19:
//#line 85 "exemploGC.y"
{ 
			 System.out.println("\tPOPL %EAX"); 
			 System.out.println("\tCALL _write");	
			 System.out.println("\tCALL _writeln"); 
                        }
break;
case 20:
//#line 92 "exemploGC.y"
{
							
				System.out.println("\tPUSHL $_"+val_peek(2).sval);
									System.out.println("\tCALL _read");
									System.out.println("\tPOPL %EDX");
									System.out.println("\tMOVL %EAX, (%EDX)");
									
								}
break;
case 21:
//#line 101 "exemploGC.y"
{		
					/* alocando rotulos*/
					pRot.push(proxRot);  proxRot += 2;
					pBreakContinue.push(proxBreakContinue); proxBreakContinue += 2;
					/* botando primeiro rotulo para teste de condicao*/
					System.out.printf("rot_%02d:\n",pRot.peek());
				  }
break;
case 22:
//#line 108 "exemploGC.y"
{
			 							System.out.println("\tPOPL %EAX   # desvia se falso...");
											System.out.println("\tCMPL $0, %EAX");
											System.out.printf("\tJE rot_%02d\n", (int)pRot.peek()+1);
										}
break;
case 23:
//#line 113 "exemploGC.y"
{
						/* continue*/
						System.out.printf("\nrot_BreakContinue_%02d:\n",pBreakContinue.peek());
						/* jump de retorno do while*/
				  		System.out.printf("\tJMP rot_%02d   # terminou cmd na linha de cima\n", pRot.peek());
						System.out.printf("rot_%02d:\n",(int)pRot.peek()+1);
						/* break */
						System.out.printf("\nrot_BreakContinue_%02d:\n",pBreakContinue.peek() + 1);
						System.out.println();
						/* limpando as pilhas para for e while encadeado*/
						pBreakContinue.pop();
						pRot.pop();	
							
		}
break;
case 24:
//#line 127 "exemploGC.y"
{
			/* alocando rotulos*/
			pRot.push(proxRot);  proxRot += 2;
			pBreakContinue.push(proxBreakContinue); proxBreakContinue += 2;
			System.out.printf("rot_%02d:\n",pRot.peek());
			}
break;
case 25:
//#line 134 "exemploGC.y"
{
			/* continue */
			System.out.printf("\nrot_BreakContinue_%02d:\n",pBreakContinue.peek());
			/* jump condicional normal do while*/
			System.out.println("\tPOPL %EAX   # desvia se falso...");
			System.out.println("\tCMPL $1, %EAX");
			System.out.printf("\tJE rot_%02d\n", (int)pRot.peek());
			/* System.out.printf("\tJMP rot_%02d   # terminou cmd na linha de cima\n", pRot.peek());*/
			/* System.out.printf("rot_%02d:\n",(int)pRot.peek()+1);*/
			
			/* break */
			System.out.printf("\nrot_BreakContinue_%02d:\n",pBreakContinue.peek() + 1);
			System.out.println();
			/* limpando as pilhas para for e while encadeado*/
			pBreakContinue.pop();
			pRot.pop();
							
		}
break;
case 26:
//#line 152 "exemploGC.y"
{System.out.println("\n# inicio for\n");}
break;
case 27:
//#line 152 "exemploGC.y"
{
			System.out.println("\n# fim primeira expressao");
			System.out.println("\tPOPL %EAX");
			pRot.push(proxRot);  proxRot += 4;
			pBreakContinue.push(proxBreakContinue); proxBreakContinue += 2;
			System.out.printf("rot_%02d:\n",pRot.peek());
			System.out.println();
			}
break;
case 28:
//#line 161 "exemploGC.y"
{
				System.out.println("\n #fim da segunda expressao");
				System.out.println("\tPOPL %EAX");
				System.out.println("\tCMPL $0, %EAX");
				System.out.printf("\tJE rot_%02d\n", pRot.peek() + 1);
				System.out.printf("\tJMP rot_%02d\n", pRot.peek() + 2);
				System.out.printf("rot_%02d:\n",pRot.peek() + 3);
				System.out.println();
			 }
break;
case 29:
//#line 171 "exemploGC.y"
{
				System.out.println("\n #fim da terceira expressao");
				System.out.println("\tPOPL %EAX");
				System.out.printf("\tJMP rot_%02d\n", pRot.peek());
				System.out.printf("rot_%02d:\n",pRot.peek() + 2);
				System.out.println();
			}
break;
case 30:
//#line 178 "exemploGC.y"
{

				/* continue*/
				System.out.printf("\nrot_BreakContinue_%02d:\n",pBreakContinue.peek());
				/* resto do codigo do for*/
				System.out.println("\n#fim do comando ");
				System.out.printf("\tJMP rot_%02d\n", pRot.peek() + 3);
				System.out.printf("rot_%02d:\n",pRot.peek() + 1);
				/* break */
				System.out.printf("\nrot_BreakContinue_%02d:\n",pBreakContinue.peek() + 1);
				System.out.println();
				/* limpando as pilhas para for e while encadeado*/
				pBreakContinue.pop();
				pRot.pop();
			}
break;
case 31:
//#line 194 "exemploGC.y"
{	
											pRot.push (proxRot);  proxRot += 2;
															
											System.out.println("\tPOPL %EAX");
											System.out.println("\tCMPL $0, %EAX");
											System.out.printf("\tJE rot_%02d\n", pRot.peek());
										}
break;
case 32:
//#line 203 "exemploGC.y"
{
											System.out.printf("rot_%02d:\n",pRot.peek()+1);
											pRot.pop();
										}
break;
case 33:
//#line 207 "exemploGC.y"
{ System.out.printf("\tJMP rot_BreakContinue_%02d\n", pBreakContinue.peek() + 1); }
break;
case 34:
//#line 208 "exemploGC.y"
{ System.out.printf("\tJMP rot_BreakContinue_%02d\n", pBreakContinue.peek()); }
break;
case 36:
//#line 211 "exemploGC.y"
{
		System.out.println("\tPUSHL $1");
	}
break;
case 37:
//#line 218 "exemploGC.y"
{
					System.out.printf("\tJMP rot_%02d\n", pRot.peek()+1);
					System.out.printf("rot_%02d:\n",pRot.peek());
								
										}
break;
case 39:
//#line 227 "exemploGC.y"
{
		    System.out.printf("\tJMP rot_%02d\n", pRot.peek()+1);
				System.out.printf("rot_%02d:\n",pRot.peek());
				}
break;
case 40:
//#line 234 "exemploGC.y"
{ Gerador.EXP.NUM(val_peek(0).ival);     }
break;
case 41:
//#line 235 "exemploGC.y"
{ Gerador.EXP.TRUE();      }
break;
case 42:
//#line 236 "exemploGC.y"
{ Gerador.EXP.FALSE();     }
break;
case 43:
//#line 237 "exemploGC.y"
{ Gerador.EXP.ID(val_peek(0).sval); 	   }
break;
case 44:
//#line 238 "exemploGC.y"
{ Gerador.EXP.POS_INC(val_peek(1).sval); }
break;
case 45:
//#line 239 "exemploGC.y"
{ Gerador.EXP.PRE_INC(val_peek(0).sval); }
break;
case 47:
//#line 241 "exemploGC.y"
{ Gerador.EXP.Negacao();       }
break;
case 48:
//#line 242 "exemploGC.y"
{ Gerador.EXP.Aritmetica('+'); }
break;
case 49:
//#line 243 "exemploGC.y"
{ Gerador.EXP.Aritmetica('-'); }
break;
case 50:
//#line 244 "exemploGC.y"
{ Gerador.EXP.Aritmetica('*'); }
break;
case 51:
//#line 245 "exemploGC.y"
{ Gerador.EXP.Aritmetica('/'); }
break;
case 52:
//#line 246 "exemploGC.y"
{ Gerador.EXP.Aritmetica('%'); }
break;
case 53:
//#line 247 "exemploGC.y"
{ Gerador.EXP.Relacional('>'); }
break;
case 54:
//#line 248 "exemploGC.y"
{ Gerador.EXP.Relacional('<'); }
break;
case 55:
//#line 249 "exemploGC.y"
{ Gerador.EXP.Relacional(EQ);  }
break;
case 56:
//#line 250 "exemploGC.y"
{ Gerador.EXP.Relacional(LEQ); }
break;
case 57:
//#line 251 "exemploGC.y"
{ Gerador.EXP.Relacional(GEQ); }
break;
case 58:
//#line 252 "exemploGC.y"
{ Gerador.EXP.Relacional(NEQ); }
break;
case 59:
//#line 253 "exemploGC.y"
{ Gerador.EXP.Logica(OR);      }
break;
case 60:
//#line 254 "exemploGC.y"
{ Gerador.EXP.Logica(AND);     }
break;
case 61:
//#line 255 "exemploGC.y"
{ Gerador.EXP.ATRIB(val_peek(2).sval);       }
break;
case 62:
//#line 256 "exemploGC.y"
{                 			   }
break;
case 63:
//#line 257 "exemploGC.y"
{                              }
break;
case 64:
//#line 260 "exemploGC.y"
{ yyval.sval = val_peek(0).sval; }
break;
case 65:
//#line 261 "exemploGC.y"
{ yyval.sval = val_peek(3).sval; }
break;
//#line 1118 "Parser.java"
//########## END OF USER-SUPPLIED ACTIONS ##########
    }//switch
    //#### Now let's reduce... ####
    if (yydebug) debug("reduce");
    state_drop(yym);             //we just reduced yylen states
    yystate = state_peek(0);     //get new state
    val_drop(yym);               //corresponding value drop
    yym = yylhs[yyn];            //select next TERMINAL(on lhs)
    if (yystate == 0 && yym == 0)//done? 'rest' state and at first TERMINAL
      {
      if (yydebug) debug("After reduction, shifting from state 0 to state "+YYFINAL+"");
      yystate = YYFINAL;         //explicitly say we're done
      state_push(YYFINAL);       //and save it
      val_push(yyval);           //also save the semantic value of parsing
      if (yychar < 0)            //we want another character?
        {
        yychar = yylex();        //get next character
        if (yychar<0) yychar=0;  //clean, if necessary
        if (yydebug)
          yylexdebug(yystate,yychar);
        }
      if (yychar == 0)          //Good exit (if lex returns 0 ;-)
         break;                 //quit the loop--all DONE
      }//if yystate
    else                        //else not done yet
      {                         //get next state and push, for next yydefred[]
      yyn = yygindex[yym];      //find out where to go
      if ((yyn != 0) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn]; //get new state
      else
        yystate = yydgoto[yym]; //else go to new defred
      if (yydebug) debug("after reduction, shifting from state "+state_peek(0)+" to state "+yystate+"");
      state_push(yystate);     //going again, so push state & val...
      val_push(yyval);         //for next action
      }
    }//main loop
  return 0;//yyaccept!!
}
//## end of method parse() ######################################



//## run() --- for Thread #######################################
/**
 * A default run method, used for operating this parser
 * object in the background.  It is intended for extending Thread
 * or implementing Runnable.  Turn off with -Jnorun .
 */
public void run()
{
  yyparse();
}
//## end of method run() ########################################



//## Constructors ###############################################
/**
 * Default constructor.  Turn off with -Jnoconstruct .

 */
public Parser()
{
  //nothing to do
}


/**
 * Create a parser, setting the debug to true or false.
 * @param debugMe true for debugging, false for no debug.
 */
public Parser(boolean debugMe)
{
  yydebug=debugMe;
}
//###############################################################



}
//################### END OF CLASS ##############################
