
//Métodos Para a geração de código
public class Gerador{

	public static class EXP{

		public static void Aritmetica(int oparit) {
				
				System.out.println("\tPOPL %EBX");
				System.out.println("\tPOPL %EAX");

				switch (oparit) {
					case '+' : System.out.println("\tADDL %EBX, %EAX" ); break;
					case '-' : System.out.println("\tSUBL %EBX, %EAX" ); break;
					case '*' : System.out.println("\tIMULL %EBX, %EAX" ); break;

					case '/': 
							System.out.println("\tMOVL $0, %EDX");
							System.out.println("\tIDIVL %EBX");
							break;
					case '%': 
							System.out.println("\tMOVL $0, %EDX");
							System.out.println("\tIDIVL %EBX");
							System.out.println("\tMOVL %EDX, %EAX");
							break;
				}

				System.out.println("\tPUSHL %EAX");
			}
	
		public static void Relacional(int oprel) {

			System.out.println("\tPOPL %EAX");
			System.out.println("\tPOPL %EDX");
			System.out.println("\tCMPL %EAX, %EDX");
			System.out.println("\tMOVL $0, %EAX");
			
			switch (oprel) {
				case '<':  			System.out.println("\tSETL  %AL"); break;
				case '>':  			System.out.println("\tSETG  %AL"); break;
				case Parser.EQ:  	System.out.println("\tSETE  %AL"); break;
				case Parser.GEQ: 	System.out.println("\tSETGE %AL"); break;
				case Parser.LEQ: 	System.out.println("\tSETLE %AL"); break;
				case Parser.NEQ: 	System.out.println("\tSETNE %AL"); break;
			}
			
			System.out.println("\tPUSHL %EAX");
	}

		public static void Logica(int oplog) {

			System.out.println("\tPOPL %EDX");
			System.out.println("\tPOPL %EAX");

			System.out.println("\tCMPL $0, %EAX");
			System.out.println("\tMOVL $0, %EAX");
			System.out.println("\tSETNE %AL");
			System.out.println("\tCMPL $0, %EDX");
			System.out.println("\tMOVL $0, %EDX");
			System.out.println("\tSETNE %DL");

			switch (oplog) {
					case Parser.OR:  System.out.println("\tORL  %EDX, %EAX");  break;
					case Parser.AND: System.out.println("\tANDL  %EDX, %EAX"); break;
		}

			System.out.println("\tPUSHL %EAX");
		}

		public static void Negacao(){
			System.out.println("\tPOPL %EAX" );
			System.out.println("	\tNEGL %EAX" );
			System.out.println("	\tPUSHL %EAX");
		}
		
		public static void NUM(int $1){
			System.out.println("\tPUSHL $"+$1);
		}

		public static void ID(String $1){
			System.out.println("\tPUSHL _"+$1);
		}

		public static void TRUE(){
			System.out.println("\tPUSHL $1");
		}

		public static void FALSE(){
			System.out.println("\tPUSHL $0");
		}
		
		public static void POS_INC(String $1){
			System.out.println("\tPUSHL _"+$1);
			System.out.println("\tPUSHL _"+$1);
			System.out.println("\tPUSHL $1");
			Aritmetica('+');
			System.out.println("\tPOPL %EDX");
			System.out.println("\tMOVL %EDX, _"+$1);
		}

		public static void 	PRE_INC(String $2){
			System.out.println("\tPUSHL _"+$2);
			System.out.println("\tPUSHL $1");
			Aritmetica('+');
			System.out.println("\tPOPL %EDX");
			System.out.println("\tMOVL %EDX, _"+$2);
			System.out.println("\tPUSHL _"+$2);
		}

		public static void ATRIB(String $1){
			System.out.println("\tPOPL %EDX");
			System.out.println("\tPUSHL %EDX");
			System.out.println("\tMOVL %EDX, _"+$1);
		}


	}


}