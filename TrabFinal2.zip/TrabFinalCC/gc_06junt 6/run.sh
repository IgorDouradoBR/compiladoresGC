ARQ=$(basename "$1" | sed "s/\.cmm//")

java Parser "$ARQ.cmm" > "$ARQ.s"
REM 32 bits
REM as -o "$ARQ.o" "$ARQ.s"
REM ld -o "$ARQ" "$ARQ.o"

REM 64 bits
REM Caso você esteja usando o MinGW-w64 no Windows, use o seguinte comando:
as --32 -o "$ARQ.o" "$ARQ.s"
ld -m i386pe -s -o "$ARQ.exe" "$ARQ.o"
